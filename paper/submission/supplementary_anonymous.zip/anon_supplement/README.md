# Anonymous review supplement

Updated 11 November 2026. This supports the pilot audit and completed controlled training follow-up. No model weights, credentials or personal reviewer submissions are distributed.

## Quick verification (CPU only, Python 3.9+; no packages)

From this folder run `python3 -B verify_scores.py`. It checks checksums, the 3,000-row coverage, all 30 strict checkpoint/form counts, the exact family bootstrap and the 331 final human-label rows. Expected primary: -4.333333 pp [-8.000000, -0.666667], Harm. This script is a post-study verification utility, not a replacement registered analysis or a rescoring rule.

## Contents and limits

- `phase2/scored_outcomes.csv`: derived stored strict outcomes, no question text, gold or generated answers. Each checkpoint has 100 matched families × E/R/C. Bootstrap families jointly across the three fixed seeds; do not treat 300 seed/family records as independent families.
- `phase2/phase2_analysis.*`: original registered final analysis, with separate strict/numeric endpoints, scope and interval limitations. `final_audit.*`: recorded human labels/summary for the ER/EC C failures only. No personal identities or handwritten submissions.
- `phase2/execution_metadata.json`: recorded immutable revisions, configurations and environments. It documents the actual stack; do not replace it with current package defaults.
- `data/`: pilot datasets and TRAIN/DEV. Final-test wording, raw final-test responses and weights are intentionally withheld pending camera-ready release. Therefore this bundle supports score-level reproduction but cannot independently rescore or regenerate FINAL_TEST.
- `implementation/`: unchanged source files from the implementation manifest, retained for inspection. Builders that need withheld FINAL_TEST data are not self-contained runnable training/evaluation packages here. No claim of full GPU reproduction from this review bundle.
- `protocol/`: plans, deviations, freezes; identifying repository link removed in release copies. Original and release hashes are distinguished in `SOURCE_MANIFEST.json`. Relative links referencing the private working tree may not resolve here.
- `instructions/`: original empty review interfaces/README and audit instructions (contains pilot reference material, not returned reviewer answers).
- `results/`: separately reported pilot cohorts. Their definitions/review differ; do not pool.

## Compute accounting

Measured committed FINAL_TEST generation latency totals 8.291 T4-hours over 3,000 outputs. Nine training runs × 60 updates at approximately 20 seconds/update imply about 3 T4-hours of updates. Neither includes all model loading, checkpointing, failed launches, DEV, screening or engineering work; a complete project-wide compute total is unavailable. These are component costs, not a full budget.

## Release/provenance

Code MIT; authored data CC BY 4.0. Upstream models remain under their own licenses (Qwen3 Apache 2.0; Llama 3.2 Community License). No upstream weights are redistributed. AI drafting/checking and human review are described in the paper; stored human labels are evidence records, not an independent certification of human activity. The protocol discloses pre-training CPU test access beyond the byte-hash-only rule. Results were not changed after the negative finding.
