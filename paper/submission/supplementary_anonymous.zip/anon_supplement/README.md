# Anonymous supplementary material

For the submission "Romanized Hindi Is Harder Than Hinglish: A Scoring-Aware Audit of Small LLMs".

- `data/`: Pilot-B (70 families × E/R/C, frozen with SHA-256 in `FROZEN.md`) and the original-pilot cohort (24 families, with pseudonymous reviewer metadata). Both pre-registrations are included. The held-out Phase-2 test, development and training sets are **withheld** until the planned training study.
- `code/`: evaluation engine (`hinglish_pilot/`, frozen strict scorer v1.0.0), secondary numeric endpoint (`secondary_analysis/`), and a table and figure builder that reproduces every reported number from results ZIPs (`paper_analysis/`).
- `notebooks/`: self-contained Colab (T4) notebooks used for every reported run (data and code embedded).
- `results/`: per-rendering stored scores for all six runs, per-run summaries, and the audit (two blind AI pre-taggers plus the final human-checked labels).
- Licences: code MIT (`LICENSE`); data CC BY 4.0 (`DATA_LICENSE.md`).

Reproduce a run: upload a notebook to Colab, select a T4 GPU, Run all. Reproduce the tables: `python3 -B -m paper_analysis.build_tables <results.zip> --out <dir>` (run from `code/`).
