# DEMO — NOT RESEARCH EVIDENCE

Run status: **COMPLETE**; analysis: automatic.
6/6 outputs completed; 0 unresolved.
2 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 0/2 | 0.0% | [0.0%, 65.8%] |
| R | 0/2 | 0.0% | [0.0%, 65.8%] |
| C | 0/2 | 0.0% | [0.0%, 65.8%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 0.0 pp [0.0, 0.0]
- E-R: 0.0 pp [0.0, 0.0]
- R-C: 0.0 pp [0.0, 0.0]

Automatic invalid/truncated outputs: 6/6. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Not evidence of E+C versus E+R training benefit; no training performed. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
