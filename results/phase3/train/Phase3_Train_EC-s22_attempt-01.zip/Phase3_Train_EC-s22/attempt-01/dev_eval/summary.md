# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 37/40 | 92.5% | [80.1%, 97.4%] |
| R | 24/40 | 60.0% | [44.6%, 73.7%] |
| C | 23/40 | 57.5% | [42.2%, 71.5%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 35.0 pp [20.0, 50.0]
- E-R: 32.5 pp [15.0, 50.0]
- R-C: 2.5 pp [-20.0, 25.0]

Automatic invalid/truncated outputs: 13/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
