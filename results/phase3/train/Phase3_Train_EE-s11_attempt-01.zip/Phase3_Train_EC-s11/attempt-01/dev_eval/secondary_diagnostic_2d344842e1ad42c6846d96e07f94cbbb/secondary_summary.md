# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-754ec8e12dcc4a988602bf74131b50ef`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 35 | 87.5% | 35 | 87.5% |
| R | 40 | 20 | 50.0% | 21 | 52.5% |
| C | 40 | 22 | 55.0% | 21 | 52.5% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 33 | 2 | 2 | 3 |
| R | 18 | 16 | 3 | 3 |
| C | 20 | 15 | 1 | 4 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 4 | 2 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_unit | 5 | 3 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_unit | 4 | 1 |
| C | percent_requires_dimensionless | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
