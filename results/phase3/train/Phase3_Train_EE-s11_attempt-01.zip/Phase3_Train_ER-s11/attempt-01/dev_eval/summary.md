# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 34/40 | 85.0% | [70.9%, 92.9%] |
| R | 18/40 | 45.0% | [30.7%, 60.2%] |
| C | 23/40 | 57.5% | [42.2%, 71.5%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 27.5 pp [12.5, 42.5]
- E-R: 40.0 pp [22.5, 57.5]
- R-C: -12.5 pp [-27.5, 2.5]

Automatic invalid/truncated outputs: 18/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
