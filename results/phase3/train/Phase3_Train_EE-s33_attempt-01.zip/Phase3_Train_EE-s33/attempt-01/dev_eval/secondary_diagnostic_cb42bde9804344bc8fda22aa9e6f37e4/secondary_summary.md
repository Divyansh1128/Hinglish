# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-a3e9f17b22454100904a11574c80be6a`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 34 | 85.0% | 36 | 90.0% |
| R | 40 | 23 | 57.5% | 23 | 57.5% |
| C | 40 | 23 | 57.5% | 22 | 55.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 33 | 3 | 3 | 1 |
| R | 21 | 15 | 2 | 2 |
| C | 21 | 15 | 1 | 3 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 3 | 3 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_unit | 3 | 2 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_unit | 2 | 1 |
| C | percent_requires_dimensionless | 1 | 0 |
| C | truncated | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
