# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 33/40 | 82.5% | [68.1%, 91.3%] |
| R | 19/40 | 47.5% | [32.9%, 62.5%] |
| C | 21/40 | 52.5% | [37.5%, 67.1%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 30.0 pp [15.0, 45.0]
- E-R: 35.0 pp [17.5, 52.5]
- R-C: -5.0 pp [-25.0, 15.0]

Automatic invalid/truncated outputs: 21/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
