# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-643474dbfe9a483fa303a7c9a7ef89c1`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 33 | 82.5% | 34 | 85.0% |
| R | 40 | 19 | 47.5% | 19 | 47.5% |
| C | 40 | 21 | 52.5% | 20 | 50.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 30 | 3 | 4 | 3 |
| R | 16 | 17 | 3 | 4 |
| C | 17 | 16 | 3 | 4 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 6 | 4 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_answer | 1 | 0 |
| R | invalid_unit | 4 | 3 |
| R | percent_requires_dimensionless | 1 | 0 |
| R | truncated | 1 | 0 |
| C | invalid_answer | 1 | 0 |
| C | invalid_unit | 5 | 3 |
| C | percent_requires_dimensionless | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
