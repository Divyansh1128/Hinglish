# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `pilot_adjudicated-8218ed3d220b41ed867727d5c888a930`; completed renderings: 72.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 24 | 24 | 100.0% | 24 | 100.0% |
| R | 24 | 22 | 91.7% | 22 | 91.7% |
| C | 24 | 24 | 100.0% | 24 | 100.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 24 | 0 | 0 | 0 |
| R | 22 | 2 | 0 | 0 |
| C | 24 | 0 | 0 | 0 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
