# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `pilot_b-bdfdb8cc35794bd68ef87ad29eddad4e`; completed renderings: 210.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 70 | 66 | 94.3% | 51 | 72.9% |
| R | 70 | 60 | 85.7% | 58 | 82.9% |
| C | 70 | 66 | 94.3% | 58 | 82.9% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 48 | 19 | 3 | 0 |
| R | 57 | 11 | 1 | 1 |
| C | 57 | 12 | 1 | 0 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 3 | 3 |
| R | invalid_unit | 2 | 1 |
| C | invalid_unit | 1 | 1 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
