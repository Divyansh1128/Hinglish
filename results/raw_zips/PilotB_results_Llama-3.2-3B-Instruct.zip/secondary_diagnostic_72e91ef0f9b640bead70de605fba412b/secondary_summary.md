# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `pilot_b-7ed6648488b4418d97e0467c57e3d88f`; completed renderings: 210.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 70 | 66 | 94.3% | 66 | 94.3% |
| R | 70 | 40 | 57.1% | 40 | 57.1% |
| C | 70 | 49 | 70.0% | 49 | 70.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 66 | 3 | 0 | 1 |
| R | 40 | 24 | 0 | 6 |
| C | 49 | 17 | 0 | 4 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_numeric_grouping | 1 | 0 |
| R | invalid_unit | 1 | 0 |
| R | truncated | 5 | 0 |
| C | invalid_numeric_grouping | 1 | 0 |
| C | missing_final | 1 | 0 |
| C | truncated | 2 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
