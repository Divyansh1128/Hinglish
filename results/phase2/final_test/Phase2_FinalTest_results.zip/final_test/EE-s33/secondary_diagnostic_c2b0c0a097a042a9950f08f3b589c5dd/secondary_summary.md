# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-79f763077420466ebdec1682c22437a2`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 59 | 59.0% | 77 | 77.0% |
| R | 100 | 39 | 39.0% | 54 | 54.0% |
| C | 100 | 44 | 44.0% | 57 | 57.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 56 | 14 | 21 | 9 |
| R | 37 | 27 | 17 | 19 |
| C | 43 | 23 | 14 | 20 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 26 | 21 |
| E | percent_requires_dimensionless | 4 | 0 |
| R | invalid_unit | 32 | 17 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 2 | 0 |
| C | invalid_unit | 27 | 14 |
| C | multiple_finals | 1 | 0 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
