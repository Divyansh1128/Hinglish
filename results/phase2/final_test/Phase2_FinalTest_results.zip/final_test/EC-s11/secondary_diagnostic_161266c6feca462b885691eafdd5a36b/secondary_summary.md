# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-11b4206dc26e4249a3660bf268955419`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 64 | 64.0% | 78 | 78.0% |
| R | 100 | 43 | 43.0% | 55 | 55.0% |
| C | 100 | 41 | 41.0% | 49 | 49.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 62 | 15 | 16 | 7 |
| R | 41 | 28 | 14 | 17 |
| C | 40 | 29 | 9 | 22 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_answer | 1 | 0 |
| E | invalid_unit | 18 | 16 |
| E | percent_requires_dimensionless | 4 | 0 |
| R | final_not_terminal_line | 1 | 0 |
| R | invalid_unit | 26 | 14 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 3 | 0 |
| C | invalid_unit | 24 | 9 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
