# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-d28adcc7cc5a49b4b6c18906092cdd12`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 58 | 58.0% | 76 | 76.0% |
| R | 100 | 41 | 41.0% | 52 | 52.0% |
| C | 100 | 46 | 46.0% | 56 | 56.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 55 | 16 | 21 | 8 |
| R | 39 | 29 | 13 | 19 |
| C | 44 | 25 | 12 | 19 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 25 | 21 |
| E | percent_requires_dimensionless | 4 | 0 |
| R | invalid_unit | 28 | 13 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 2 | 0 |
| C | invalid_unit | 25 | 12 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
