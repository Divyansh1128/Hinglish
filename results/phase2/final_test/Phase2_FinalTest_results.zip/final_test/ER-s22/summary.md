# PHASE-2 FINAL_TEST — confirmatory evaluation

Run status: **COMPLETE**; analysis: automatic.
300/300 outputs completed; 0 unresolved.
100 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 56/100 | 56.0% | [46.2%, 65.3%] |
| R | 35/100 | 35.0% | [26.4%, 44.7%] |
| C | 47/100 | 47.0% | [37.5%, 56.7%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 9.0 pp [-1.0, 19.0]
- E-R: 21.0 pp [11.0, 31.0]
- R-C: -12.0 pp [-22.0, -2.0]

Automatic invalid/truncated outputs: 91/300. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
