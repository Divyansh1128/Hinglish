# PHASE-2 FINAL_TEST — confirmatory evaluation

Run status: **COMPLETE**; analysis: automatic.
300/300 outputs completed; 0 unresolved.
100 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 61/100 | 61.0% | [51.2%, 70.0%] |
| R | 37/100 | 37.0% | [28.2%, 46.8%] |
| C | 50/100 | 50.0% | [40.4%, 59.6%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 11.0 pp [1.0, 21.0]
- E-R: 24.0 pp [14.0, 35.0]
- R-C: -13.0 pp [-22.0, -4.0]

Automatic invalid/truncated outputs: 88/300. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
