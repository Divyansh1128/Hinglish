# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-3ede70f24b4a42c4935888926123f192`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 62 | 62.0% | 76 | 76.0% |
| R | 100 | 41 | 41.0% | 52 | 52.0% |
| C | 100 | 44 | 44.0% | 58 | 58.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 60 | 17 | 16 | 7 |
| R | 40 | 30 | 12 | 18 |
| C | 44 | 28 | 14 | 14 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 19 | 16 |
| E | percent_requires_dimensionless | 4 | 0 |
| R | invalid_answer | 1 | 0 |
| R | invalid_unit | 24 | 12 |
| R | multiple_finals | 1 | 0 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 3 | 0 |
| C | invalid_unit | 20 | 14 |
| C | multiple_finals | 1 | 0 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
