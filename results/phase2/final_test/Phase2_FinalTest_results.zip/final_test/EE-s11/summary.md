# PHASE-2 FINAL_TEST — confirmatory evaluation

Run status: **COMPLETE**; analysis: automatic.
300/300 outputs completed; 0 unresolved.
100 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 62/100 | 62.0% | [52.2%, 70.9%] |
| R | 41/100 | 41.0% | [31.9%, 50.8%] |
| C | 44/100 | 44.0% | [34.7%, 53.8%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 18.0 pp [9.0, 27.0]
- E-R: 21.0 pp [11.0, 31.0]
- R-C: -3.0 pp [-14.0, 8.0]

Automatic invalid/truncated outputs: 81/300. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
