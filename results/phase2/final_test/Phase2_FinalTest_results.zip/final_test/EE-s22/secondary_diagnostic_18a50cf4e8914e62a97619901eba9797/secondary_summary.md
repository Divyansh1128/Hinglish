# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-3fc3f2cf06524aac953870f34ac56cc7`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 63 | 63.0% | 81 | 81.0% |
| R | 100 | 41 | 41.0% | 49 | 49.0% |
| C | 100 | 41 | 41.0% | 53 | 53.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 60 | 11 | 21 | 8 |
| R | 39 | 33 | 10 | 18 |
| C | 39 | 29 | 14 | 18 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 25 | 21 |
| E | percent_requires_dimensionless | 4 | 0 |
| R | invalid_unit | 23 | 10 |
| R | multiple_finals | 1 | 0 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 2 | 0 |
| C | invalid_unit | 25 | 14 |
| C | multiple_finals | 1 | 0 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
