# PHASE-2 FINAL_TEST — confirmatory evaluation

Run status: **COMPLETE**; analysis: automatic.
300/300 outputs completed; 0 unresolved.
100 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 85/100 | 85.0% | [76.7%, 90.7%] |
| R | 63/100 | 63.0% | [53.2%, 71.8%] |
| C | 66/100 | 66.0% | [56.3%, 74.5%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 19.0 pp [11.0, 28.0]
- E-R: 22.0 pp [12.0, 32.0]
- R-C: -3.0 pp [-13.0, 6.0]

Automatic invalid/truncated outputs: 47/300. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
