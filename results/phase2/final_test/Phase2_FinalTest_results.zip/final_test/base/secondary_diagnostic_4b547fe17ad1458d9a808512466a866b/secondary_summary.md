# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-627d68ad676f426c8c698c0258d433d6`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 85 | 85.0% | 90 | 90.0% |
| R | 100 | 63 | 63.0% | 73 | 73.0% |
| C | 100 | 66 | 66.0% | 71 | 71.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 82 | 7 | 8 | 3 |
| R | 62 | 20 | 11 | 7 |
| C | 63 | 19 | 8 | 10 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 8 | 8 |
| E | percent_requires_dimensionless | 3 | 0 |
| R | invalid_number | 2 | 0 |
| R | invalid_unit | 12 | 11 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 2 | 0 |
| C | invalid_number | 1 | 0 |
| C | invalid_unit | 11 | 8 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
