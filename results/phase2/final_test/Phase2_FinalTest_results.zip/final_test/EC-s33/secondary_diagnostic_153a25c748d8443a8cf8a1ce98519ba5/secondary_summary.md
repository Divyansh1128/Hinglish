# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_final_test-e3c4af4c860e456eb7f9f6853c8173a8`; completed renderings: 300.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 100 | 54 | 54.0% | 75 | 75.0% |
| R | 100 | 40 | 40.0% | 52 | 52.0% |
| C | 100 | 41 | 41.0% | 51 | 51.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 52 | 17 | 23 | 8 |
| R | 38 | 29 | 14 | 19 |
| C | 40 | 29 | 11 | 20 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 27 | 23 |
| E | percent_requires_dimensionless | 4 | 0 |
| R | invalid_answer | 1 | 0 |
| R | invalid_unit | 28 | 14 |
| R | percent_requires_dimensionless | 4 | 0 |
| C | invalid_answer | 3 | 0 |
| C | invalid_unit | 23 | 11 |
| C | multiple_finals | 1 | 0 |
| C | percent_requires_dimensionless | 4 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
