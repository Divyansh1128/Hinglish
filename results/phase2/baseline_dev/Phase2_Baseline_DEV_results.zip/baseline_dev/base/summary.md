# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 33/40 | 82.5% | [68.1%, 91.3%] |
| R | 19/40 | 47.5% | [32.9%, 62.5%] |
| C | 24/40 | 60.0% | [44.6%, 73.7%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 22.5 pp [2.5, 42.5]
- E-R: 35.0 pp [15.0, 55.0]
- R-C: -12.5 pp [-27.5, 2.5]

Automatic invalid/truncated outputs: 12/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
