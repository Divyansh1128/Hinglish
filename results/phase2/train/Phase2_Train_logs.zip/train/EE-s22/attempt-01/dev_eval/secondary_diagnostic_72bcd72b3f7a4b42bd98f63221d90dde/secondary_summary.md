# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-0cf020754dfa4cc99d5d8eb0331abff1`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 24 | 60.0% | 29 | 72.5% |
| R | 40 | 15 | 37.5% | 18 | 45.0% |
| C | 40 | 20 | 50.0% | 19 | 47.5% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 24 | 6 | 5 | 5 |
| R | 15 | 17 | 3 | 5 |
| C | 19 | 16 | 0 | 5 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_answer | 1 | 0 |
| E | invalid_unit | 8 | 5 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_unit | 7 | 3 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_answer | 1 | 0 |
| C | invalid_unit | 3 | 0 |
| C | percent_requires_dimensionless | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
