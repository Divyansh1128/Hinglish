# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-95d5985f3f094c9a996cce70e8e58b49`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 22 | 55.0% | 27 | 67.5% |
| R | 40 | 9 | 22.5% | 11 | 27.5% |
| C | 40 | 18 | 45.0% | 18 | 45.0% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 22 | 7 | 5 | 6 |
| R | 9 | 23 | 2 | 6 |
| C | 17 | 17 | 1 | 5 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_answer | 1 | 0 |
| E | invalid_unit | 9 | 5 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_answer | 1 | 0 |
| R | invalid_unit | 6 | 2 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_answer | 1 | 0 |
| C | invalid_unit | 4 | 1 |
| C | percent_requires_dimensionless | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
