# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 22/40 | 55.0% | [39.8%, 69.3%] |
| R | 9/40 | 22.5% | [12.3%, 37.5%] |
| C | 18/40 | 45.0% | [30.7%, 60.2%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 10.0 pp [-5.0, 25.0]
- E-R: 32.5 pp [17.5, 47.5]
- R-C: -22.5 pp [-40.0, -5.0]

Automatic invalid/truncated outputs: 25/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
