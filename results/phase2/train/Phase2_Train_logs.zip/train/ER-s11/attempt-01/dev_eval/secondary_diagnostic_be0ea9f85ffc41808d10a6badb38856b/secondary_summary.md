# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-9b314f87e5c04bcbba04affe21ea92bf`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 23 | 57.5% | 27 | 67.5% |
| R | 40 | 12 | 30.0% | 14 | 35.0% |
| C | 40 | 17 | 42.5% | 19 | 47.5% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 22 | 8 | 5 | 5 |
| R | 12 | 20 | 2 | 6 |
| C | 16 | 17 | 3 | 4 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 9 | 5 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_answer | 2 | 0 |
| R | invalid_unit | 5 | 2 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_answer | 1 | 0 |
| C | invalid_unit | 5 | 3 |
| C | missing_final | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
