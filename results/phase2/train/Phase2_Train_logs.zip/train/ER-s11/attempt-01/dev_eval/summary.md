# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 23/40 | 57.5% | [42.2%, 71.5%] |
| R | 12/40 | 30.0% | [18.1%, 45.4%] |
| C | 17/40 | 42.5% | [28.5%, 57.8%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 15.0 pp [0.0, 30.0]
- E-R: 27.5 pp [10.0, 45.0]
- R-C: -12.5 pp [-30.0, 2.5]

Automatic invalid/truncated outputs: 25/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
