# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-20291630173648a2ac8a9e8a8c13f319`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 23 | 57.5% | 27 | 67.5% |
| R | 40 | 13 | 32.5% | 16 | 40.0% |
| C | 40 | 17 | 42.5% | 19 | 47.5% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 22 | 8 | 5 | 5 |
| R | 13 | 18 | 3 | 6 |
| C | 16 | 16 | 3 | 5 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_answer | 1 | 0 |
| E | invalid_unit | 7 | 5 |
| E | percent_requires_dimensionless | 1 | 0 |
| E | truncated | 1 | 0 |
| R | invalid_answer | 1 | 0 |
| R | invalid_unit | 7 | 3 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_answer | 2 | 0 |
| C | invalid_unit | 5 | 3 |
| C | percent_requires_dimensionless | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
