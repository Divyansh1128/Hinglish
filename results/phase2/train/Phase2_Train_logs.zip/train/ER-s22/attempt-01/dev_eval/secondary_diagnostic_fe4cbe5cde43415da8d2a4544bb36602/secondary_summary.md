# SECONDARY DIAGNOSTIC — strict v1.0.0 endpoint remains primary

Pre-registered SECONDARY endpoint (decision D018); strict v1.0.0 remains primary.

Strict accuracy copies stored `correct` unchanged. Numeric accuracy (numeric_literal_v1) checks only the sole FINAL line's literal value against gold, with no unit conversion or unit validation.
Truncated outputs fail; refusal regex hits do not veto extraction. This is not semantic accuracy, a human-reviewed score or a training-benefit result.

Run: `phase2_dev-a59ce9496feb40518c407d3f97bbdb4a`; completed renderings: 120.

| Form | N | Strict correct | Strict accuracy | Numeric correct | Numeric accuracy |
|---|---:|---:|---:|---:|---:|
| E | 40 | 24 | 60.0% | 28 | 70.0% |
| R | 40 | 11 | 27.5% | 12 | 30.0% |
| C | 40 | 21 | 52.5% | 23 | 57.5% |

Cross-tab (strict invalid means stored `invalid_reason` is non-null):

| Form | Strict valid / numeric correct | Strict valid / numeric incorrect | Strict invalid / numeric correct | Strict invalid / numeric incorrect |
|---|---:|---:|---:|---:|
| E | 24 | 6 | 4 | 6 |
| R | 10 | 19 | 2 | 9 |
| C | 20 | 13 | 3 | 4 |

Stored invalid-reason breakdown:

| Form | Strict invalid reason | Count | Numeric correct |
|---|---|---:|---:|
| E | invalid_unit | 9 | 4 |
| E | percent_requires_dimensionless | 1 | 0 |
| R | invalid_answer | 3 | 0 |
| R | invalid_unit | 7 | 2 |
| R | percent_requires_dimensionless | 1 | 0 |
| C | invalid_answer | 2 | 0 |
| C | invalid_unit | 4 | 3 |
| C | percent_requires_dimensionless | 1 | 0 |

Per-rendering extraction paths, statuses, suffixes and original flags are in `secondary_metrics.json`.
All input files are preserved; each invocation creates a new report directory.
