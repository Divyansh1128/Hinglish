# PHASE-2 DEV — sanity only; never used for selection

Run status: **COMPLETE**; analysis: automatic.
120/120 outputs completed; 0 unresolved.
40 independent families, each with E/R/C renderings.

Human review metadata are attestations, not automated proof of validity. All scored generations need independent manual audit.

| Form | Correct / families | Accuracy | Wilson 95% interval |
|---|---:|---:|---:|
| E | 25/40 | 62.5% | [47.0%, 75.8%] |
| R | 15/40 | 37.5% | [24.2%, 53.0%] |
| C | 17/40 | 42.5% | [28.5%, 57.8%] |

Paired differences (percentage points); descriptive family bootstrap:
- E-C: 20.0 pp [5.0, 35.0]
- E-R: 25.0 pp [10.0, 40.0]
- R-C: -5.0 pp [-20.0, 10.0]

Automatic invalid/truncated outputs: 23/120. Review-packet threshold: more than 3/90 requires protocol revision before scaling.
Inspect floor/ceiling effects, all format failures, language equivalence, and wrong-answer examples before choosing the next experiment.

Single checkpoint only: E+C versus E+R is analysed across all 9 adapters by the pre-registered Phase-2 analysis, not here. No significance or internal-mechanism claim.
For the executed notebook: Colab File > Download > Download .ipynb. Return it with the results ZIP.
Resource telemetry excludes download/load time from generation latency. Device free is sampled at endpoints only.
