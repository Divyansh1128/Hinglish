"""Strict JSON input contract. Human attestations cannot be machine-certified."""
import hashlib
import json
import re
from collections import Counter
from fractions import Fraction

FORMS = ('E', 'R', 'C')
TOPICS = ('comparison_remaining', 'two_step_money', 'fractions_percentages',
          'ratios', 'rates_units', 'elementary_algebra')
DEMO_LABEL = 'DEMO — NOT RESEARCH EVIDENCE'
ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}\Z')
PHASE2_MODES = ('phase2_dev', 'phase2_final_test')
# Frozen Phase-2 evaluation sets (phase2/TRAIN_DEV_FROZEN.md, phase2/FINAL_TEST_FROZEN.md).
PHASE2_SPLITS = {'phase2_dev': {'role': 'DEV', 'families': 40, 'label': 'PHASE-2 DEV: sample-based review (D027) — sanity only'},
                 'phase2_final_test': {'role': 'FINAL_TEST', 'families': 100, 'label': 'PHASE-2 FINAL_TEST: single-reviewer ACCEPT'}}
MODES = ('demo', 'reviewed', 'pilot_b', 'pilot_adjudicated', *PHASE2_MODES)
ROLES = ('PILOT_EVAL', 'SMOKE_TRAIN', 'RETIRED_DRAFT', 'CONFIRM_TRAIN', 'FINAL_TEST')
ADJUDICATED_LABEL = 'ORIGINAL PILOT — two independent human solvers; language review by one human reviewer + adjudicator (24 accepted families)'
ADJUDICATED_FORM_FIELDS = {'judgment_source', 'text_sha256', 'raw_answer', 'raw_unit', 'answer_matches_gold', 'disposition', 'classification',
                           'naturalness', 'readability', 'ambiguity_flag', 'failed_semantic_checks', 'notes'}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False, separators=(',', ':')).encode()).hexdigest()

def text(value, field):
    require(isinstance(value, str) and bool(value.strip()), f'Missing/nontext {field}')
    require(len(value) <= 20000, f'{field} exceeds size bound')
    return value

def ident(value, field):
    require(isinstance(value, str) and ID.fullmatch(value), f'Invalid {field}: use pseudonymous safe IDs')
    return value

def exact(value, field):
    require(isinstance(value, str) and len(value) <= 100 and
            re.fullmatch(r'[+-]?(?:\d+(?:\.\d+)?|\.\d+)(?:/[+-]?\d+)?', value),
            f'{field}: use an exact numeric string, not a float')
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError):
        raise ValueError(f'Invalid {field}') from None

def validate_gold(gold):
    require(isinstance(gold, dict) and set(gold) == {
        'value', 'unit', 'aliases', 'conversions', 'unit_omission_allowed', 'rounding_rule'},
        'Gold fields: value/unit/aliases/conversions/unit_omission_allowed/rounding_rule')
    exact(gold['value'], 'gold.value')
    require(isinstance(gold['unit'], str), 'gold.unit must be text')
    require(isinstance(gold['unit_omission_allowed'], bool), 'Omission policy must be boolean')
    require(isinstance(gold['aliases'], list) and all(isinstance(x, str) and x.strip() for x in gold['aliases']),
            'Invalid unit aliases')
    require(isinstance(gold['conversions'], dict), 'Invalid conversions')
    for unit, factor in gold['conversions'].items():
        text(unit, 'conversion unit')
        require(exact(factor, 'conversion factor') > 0, 'Conversion factor must be positive')
    # All accepted values are exact; if a question asks for rounding, author its
    # rounded gold in advance. Unspecified approximate equivalence is unsupported.
    require(gold['rounding_rule'] == 'exact',
            'Test 1 accepts exact gold only; supply the requested rounded value as exact gold and document it in the reference solution')
    from .scorer_v1 import score_response
    score_response('FINAL: 0', gold)  # reject conflicting aliases/conversions

def identities(record):
    return {ident(record[k], k) for k in ('family_id', 'source_family_id', 'template_group_id')}

def validate(dataset, manifest, mode):
    # pilot_b (decision D035): frozen single-reviewer evaluation set (pilot_b/FROZEN.md); not the two-reviewer pilot.
    # pilot_adjudicated (decision D036): original-pilot cohort accepted by an adjudicator after two independent reviews;
    # raw reviewer judgments are kept as entered (they may disagree with gold) and the adjudication resolves them.
    # phase2_dev / phase2_final_test: the frozen Phase-2 DEV and FINAL_TEST files, unchanged (phase2/PREREGISTRATION.md).
    require(mode in MODES, 'Mode must be demo, reviewed, pilot_b, pilot_adjudicated, phase2_dev or phase2_final_test')
    require(isinstance(dataset, dict) and dataset.get('schema_version') == 'test1-1', 'Dataset schema_version must be test1-1')
    text(dataset.get('version'), 'dataset version')
    text(dataset.get('borrowing_policy'), 'borrowing policy')
    require(dataset.get('kind') == mode, 'Dataset kind does not match execution mode')
    families = dataset.get('families')
    require(isinstance(families, list) and (len(families) == PHASE2_SPLITS[mode]['families'] if mode in PHASE2_MODES else len(families) == 30 if mode == 'reviewed' else 1 <= len(families) <= 200 if mode == 'pilot_b'
                                            else 1 <= len(families) <= 30 if mode == 'pilot_adjudicated' else 1 <= len(families) <= 6),
            'Reviewed pilot requires 30 families; demo requires 1–6')
    require(isinstance(manifest, dict) and manifest.get('schema_version') == 'test1-1', 'Split schema_version must be test1-1')
    text(manifest.get('version'), 'split version')
    require(manifest.get('kind') == mode, 'Manifest kind mismatch')
    expected_top = {'schema_version', 'version', 'kind', 'borrowing_policy', 'families'}
    require(set(dataset) == expected_top, 'Unexpected dataset fields; do not include personal details/credentials')
    require(set(manifest) == {'schema_version', 'version', 'kind', 'audit', 'development_exclusion_ids', *ROLES},
            'Unexpected/missing split fields')
    seen_ids, seen_text, render_ids = set(), set(), set()
    for family in families:
        require(set(family) == {'family_id', 'source_family_id', 'template_group_id', 'topic', 'split_role',
                'version', 'authoring_origin', 'provenance', 'source_license', 'reference_equation',
                'reference_solution_en', 'status', 'gold', 'forms', 'review'}, 'Unexpected/missing family fields')
        ids = identities(family)
        require(not ids & seen_ids, 'Repeated underlying family/source/template IDs')
        seen_ids |= ids
        require(family['topic'] in TOPICS, 'Unrecognized topic')
        require(family['split_role'] == {'reviewed': 'PILOT_EVAL', 'pilot_adjudicated': 'PILOT_EVAL', 'pilot_b': 'PILOT_B_EVAL', 'demo': 'DEMO',
                                         **{m: v['role'] for m, v in PHASE2_SPLITS.items()}}[mode], 'Wrong split role')
        for field in ('version', 'authoring_origin', 'provenance', 'source_license', 'reference_equation', 'reference_solution_en'):
            text(family[field], field)
        require(family['status'] == ('DEMO' if mode == 'demo' else 'ACCEPT'), 'Human acceptance missing or demo status invalid')
        validate_gold(family['gold'])
        require(set(family['forms']) == set(FORMS), 'Exactly E/R/C forms required')
        for form, rendering in family['forms'].items():
            require(set(rendering) == {'rendering_id', 'text', 'creator_type', 'generation_or_edit_history', 'switching_roles'},
                    'Unexpected/missing rendering fields')
            rid = ident(rendering['rendering_id'], 'rendering_id')
            require(rid not in render_ids, 'Duplicate rendering ID')
            render_ids.add(rid)
            question = text(rendering['text'], 'question')
            normalized = ' '.join(question.casefold().split())
            require(normalized not in seen_text, 'Duplicate normalized rendering')
            seen_text.add(normalized)
            require(not re.search(r'<\|[^>]+\|>|/no_think|/think', question), 'Input contains model control markers')
            for field in ('creator_type', 'generation_or_edit_history'):
                text(rendering[field], field)
            require(isinstance(rendering['switching_roles'], list), 'switching_roles must be a list')
            if mode in ('reviewed', 'pilot_b', 'pilot_adjudicated', *PHASE2_MODES) and form == 'C':
                require(bool(rendering['switching_roles']), 'C needs documented productive switching roles')
        review = family['review']
        require(set(review) == {'reviewers', 'adjudication'}, 'Unexpected/missing review fields')
        require(isinstance(review['reviewers'], list), 'Reviewers must be a list')
        if mode == 'demo':
            require(review == {'reviewers': [], 'adjudication': None}, 'Demo cannot include fabricated approvals')
            continue
        if mode == 'pilot_b':
            require(review['adjudication'] is None and len(review['reviewers']) >= 1, 'Pilot-B needs at least one reviewer attestation')
            for reviewer in review['reviewers']:
                require(isinstance(reviewer, dict) and set(reviewer) == {'reviewer_id', 'scope', 'reviewed_at'}, 'Pilot-B reviewer fields: reviewer_id/scope/reviewed_at')
                ident(reviewer['reviewer_id'], 'reviewer_id'); text(reviewer['scope'], 'review scope'); text(reviewer['reviewed_at'], 'review timestamp')
            continue
        if mode == 'pilot_adjudicated':
            validate_adjudicated_review(family, review)
            continue
        if mode in PHASE2_MODES:
            # Sample-based (TRAIN/DEV) or single-reviewer (FINAL_TEST) review is documented in the FROZEN notes; per-family
            # attestations, where present, use the Pilot-B fields.
            require(review['adjudication'] is None, 'Phase-2 data carry no adjudication')
            for reviewer in review['reviewers']:
                require(isinstance(reviewer, dict) and set(reviewer) == {'reviewer_id', 'scope', 'reviewed_at'}, 'Phase-2 reviewer fields: reviewer_id/scope/reviewed_at')
            continue
        require(len(review['reviewers']) == 2, 'Two independent reviewers required')
        reviewers = set()
        for reviewer in review['reviewers']:
            require(set(reviewer) == {'reviewer_id', 'independent_solve_before_gold', 'forms'}, 'Invalid review schema')
            reviewers.add(ident(reviewer['reviewer_id'], 'reviewer_id'))
            require(reviewer['independent_solve_before_gold'] is True, 'Independent solve before gold required')
            require(set(reviewer['forms']) == set(FORMS), 'Both reviewers must review all forms')
            for form, assessment in reviewer['forms'].items():
                require(set(assessment) == {'text_sha256', 'equation', 'answer', 'unit', 'semantic_equivalence',
                    'ambiguity_resolved', 'classification', 'naturalness', 'readability', 'disposition'}, 'Invalid form review fields')
                require(assessment['text_sha256'] == hashlib.sha256(family['forms'][form]['text'].encode()).hexdigest(),
                        'Review hash does not match current rendering; re-review edits')
                text(assessment['equation'], 'independent equation')
                require(exact(assessment['answer'], 'independent answer') == exact(family['gold']['value'], 'gold') and
                        assessment['unit'] == family['gold']['unit'], 'Independent canonical answer/unit disagrees')
                require(assessment['semantic_equivalence'] is True and assessment['ambiguity_resolved'] is True,
                        'Unresolved equivalence/ambiguity review')
                require(assessment['classification'] == form and assessment['disposition'] == 'ACCEPT', 'Classification/acceptance required')
                for field in ('naturalness', 'readability'):
                    require(type(assessment[field]) is int and 4 <= assessment[field] <= 5, 'Review ratings must be 4–5')
        require(len(reviewers) == 2, 'Reviewers must be distinct')
        adjudication = review['adjudication']
        require(isinstance(adjudication, dict) and set(adjudication) == {'adjudicator_id', 'status', 'unresolved_issues', 'reviewed_at'},
                'Adjudication required')
        require(ident(adjudication['adjudicator_id'], 'adjudicator_id') not in reviewers, 'Adjudicator must be independent')
        require(adjudication['status'] == 'ACCEPT' and adjudication['unresolved_issues'] == 0, 'Unresolved adjudication')
        text(adjudication['reviewed_at'], 'review timestamp')
    if mode == 'reviewed':
        require(Counter(f['topic'] for f in families) == Counter({t: 5 for t in TOPICS}), 'Need five independent families per topic')
    role_ids = {}
    for role in ROLES:
        require(isinstance(manifest[role], list), f'{role} must be a list')
        ids = set()
        for record in manifest[role]:
            require(set(record) == {'family_id', 'source_family_id', 'template_group_id'}, 'Split records require three identity fields only')
            current = identities(record)
            require(not ids & current, f'Duplicate identity in {role}')
            ids |= current
        role_ids[role] = ids
    for i, role in enumerate(ROLES):
        for other in ROLES[i+1:]:
            require(not role_ids[role] & role_ids[other], f'Cross-split overlap {role}/{other}')
    expected = [{k: f[k] for k in ('family_id', 'source_family_id', 'template_group_id')} for f in families]
    if mode == 'pilot_adjudicated':
        require(sorted(manifest['PILOT_EVAL'], key=digest) == sorted(expected, key=digest), 'PILOT_EVAL identities do not match data')
        require(manifest['audit'] is None, 'Adjudicated pilot split audit must be null (no separate split audit claimed)')
    elif mode == 'reviewed':
        require(sorted(manifest['PILOT_EVAL'], key=digest) == sorted(expected, key=digest), 'PILOT_EVAL identities do not match data')
        audit = manifest['audit']
        require(isinstance(audit, dict) and set(audit) == {'approved', 'reviewer_id', 'unresolved_matches', 'audited_at'}, 'Invalid split audit')
        ident(audit['reviewer_id'], 'split reviewer ID')
        require(audit['approved'] is True and audit['unresolved_matches'] == 0, 'Completed human split audit required')
        text(audit['audited_at'], 'split audit timestamp')
    else:
        require(manifest['audit'] is None, 'Demo split audit must be null')
    if mode == 'phase2_final_test':
        # Evaluated FINAL_TEST families sit in their own role; DEV and other development IDs are the exclusions.
        require(sorted(manifest['FINAL_TEST'], key=digest) == sorted(expected, key=digest), 'FINAL_TEST identities do not match data')
        excluded = {ident(x, 'exclusion ID') for x in manifest['development_exclusion_ids']}
        require(not excluded & (role_ids['CONFIRM_TRAIN'] | role_ids['FINAL_TEST']), 'Confirmatory contamination')
        require(role_ids['PILOT_EVAL'] | role_ids['SMOKE_TRAIN'] | role_ids['RETIRED_DRAFT'] <= excluded, 'Permanent development exclusions missing')
        return {'families': len(families), 'prompts': 3 * len(families),
                'status': PHASE2_SPLITS[mode]['label'] + ' — human judgments not machine verified',
                'dataset_sha256': digest(dataset), 'split_sha256': digest(manifest)}
    require(isinstance(manifest['development_exclusion_ids'], list), 'Exclusion IDs must be a list')
    excluded = {ident(x, 'exclusion ID') for x in manifest['development_exclusion_ids']}
    development = seen_ids | role_ids['PILOT_EVAL'] | role_ids['SMOKE_TRAIN'] | role_ids['RETIRED_DRAFT']
    require(development <= excluded, 'Permanent development exclusions missing; include source/template descendants')
    require(not excluded & (role_ids['CONFIRM_TRAIN'] | role_ids['FINAL_TEST']), 'Confirmatory contamination')
    require(not seen_ids & (role_ids['SMOKE_TRAIN'] | role_ids['RETIRED_DRAFT'] | role_ids['CONFIRM_TRAIN'] | role_ids['FINAL_TEST']),
            'Dataset overlaps nonpilot split')
    return {'families': len(families), 'prompts': 3 * len(families),
            'status': PHASE2_SPLITS[mode]['label'] + ' — human judgments not machine verified' if mode in PHASE2_MODES else DEMO_LABEL if mode == 'demo' else ADJUDICATED_LABEL + ' — human judgments not machine verified' if mode == 'pilot_adjudicated' else 'PILOT-B: SINGLE-REVIEWER DATA — human judgments not machine verified' if mode == 'pilot_b' else 'REVIEW METADATA PASSED — human judgments not machine verified',
            'dataset_sha256': digest(dataset), 'split_sha256': digest(manifest)}

def validate_adjudicated_review(family, review):
    """Two independent reviewers (raw judgments, not required to agree with gold) plus a distinct adjudicator."""
    require(isinstance(review['reviewers'], list) and len(review['reviewers']) == 2, 'Two independent reviewers required')
    reviewers = set()
    for reviewer in review['reviewers']:
        require(isinstance(reviewer, dict) and set(reviewer) == {'reviewer_id', 'independent', 'forms'},
                'Adjudicated reviewer fields: reviewer_id/independent/forms')
        reviewers.add(ident(reviewer['reviewer_id'], 'reviewer_id'))
        require(reviewer['independent'] is True, 'Reviewer must have worked independently')
        require(isinstance(reviewer['forms'], dict) and set(reviewer['forms']) == set(FORMS), 'Both reviewers must review all forms')
        for form, assessment in reviewer['forms'].items():
            require(isinstance(assessment, dict) and set(assessment) == ADJUDICATED_FORM_FIELDS, 'Invalid adjudicated form review fields')
            require(assessment['text_sha256'] == hashlib.sha256(family['forms'][form]['text'].encode()).hexdigest(),
                    'Review hash does not match current rendering; re-review edits')
            for field in ('raw_answer', 'raw_unit', 'notes'):
                require(isinstance(assessment[field], str) and len(assessment[field]) <= 20000, f'{field} must be text')
            for field in ('answer_matches_gold', 'ambiguity_flag'):
                require(type(assessment[field]) is bool, f'{field} must be boolean')
            # Stage-2 judgments a tool pre-filled (and the reviewer did not verify) are recorded, never presented as human review.
            require(assessment['judgment_source'] in ('human', 'ai_prefill_unverified'), 'judgment_source must be human or ai_prefill_unverified')
            require(assessment['disposition'] in ('ACCEPT', 'REVISE', 'EXCLUDE', 'PENDING'), 'Unknown reviewer disposition')
            require(assessment['classification'] in ('E', 'R', 'C', 'UNCLEAR'), 'Unknown reviewer classification')
            for field in ('naturalness', 'readability'):
                require(type(assessment[field]) is int and 1 <= assessment[field] <= 5, 'Review ratings must be integers 1–5')
            require(isinstance(assessment['failed_semantic_checks'], list) and
                    all(isinstance(x, str) and x for x in assessment['failed_semantic_checks']), 'failed_semantic_checks must be a list of names')
    require(len(reviewers) == 2, 'Reviewers must be distinct')
    adjudication = review['adjudication']
    require(isinstance(adjudication, dict) and set(adjudication) == {'adjudicator_id', 'status', 'gold_confirmed', 'reason', 'reviewed_at'},
            'Adjudication fields: adjudicator_id/status/gold_confirmed/reason/reviewed_at')
    require(ident(adjudication['adjudicator_id'], 'adjudicator_id') not in reviewers, 'Adjudicator must be independent')
    require(adjudication['status'] == 'ACCEPT' and adjudication['gold_confirmed'] is True, 'Adjudicator must ACCEPT and confirm gold')
    text(adjudication['reason'], 'adjudication reason')
    text(adjudication['reviewed_at'], 'review timestamp')

def records(dataset):
    return [dict(family_id=f['family_id'], topic=f['topic'], form=form,
                 rendering_id=f['forms'][form]['rendering_id'], input_text=f['forms'][form]['text'], gold=f['gold'])
            for f in dataset['families'] for form in FORMS]
